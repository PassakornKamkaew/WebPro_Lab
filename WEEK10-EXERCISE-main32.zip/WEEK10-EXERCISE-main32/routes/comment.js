const express = require("express");
const path = require("path");
const pool = require("../config");
const router = express.Router();

// Require multer for file upload
const multer = require("multer");
// SET STORAGE
var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./static/uploads");
  },
  filename: function (req, file, callback) {
    callback(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});
const upload = multer({ storage: storage });

// Create new comment
router.post(
  "/:blogId/comments",
  upload.single("myimage"),
  async function (req, res, next) {
    const file = req.file;
    if (!file) {
      const error = new Error("Please upload a file");
      error.httpStatusCode = 400;
      return next(error);
    }

    const comment = req.body.comment;

    const conn = await pool.getConnection();
    // Begin transaction
    await conn.beginTransaction();

    try {
      let results = await conn.query(
        "INSERT INTO comments(blog_id,comment,comments.like) VALUES(?,?,?)",
        [req.params.blogId, comment, 0]
      );
      const CommentId = results[0].insertId;

      await conn.query(
        "INSERT INTO images(comment_id,blog_id, file_path) VALUES(?,?, ?);",
        [
          CommentId,
          req.params.blogId,
          file.path.substr(6).replaceAll("\\", "/"),
        ]
      );

      await conn.commit();
      res.redirect("/blogs/" + req.params.blogId);
    } catch (err) {
      await conn.rollback();
      next(err);
    } finally {
      console.log("finally");
      conn.release();
    }
  }
);

// Create new comment
router.post("/:blogId/comments", function (req, res, next) {
  return;
});

// Update comment
router.put("/comments/:commentId", function (req, res, next) {
  return;
});

// Delete comment
router.delete("/comments/:commentId", function (req, res, next) {
  return;
});

// Delete comment
router.put("/comments/addlike/:commentId", function (req, res, next) {
  return;
});

exports.router = router;
